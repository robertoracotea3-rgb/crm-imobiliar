@echo off
rem Porneste instalarea Kira Imobiliare: se deschide fereastra in care alegi folderul pentru date.
rem Windows 10 (1809+) si 11: fara fereastra de consola. Mai vechi: fereastra PowerShell ascunsa.
set "CRMPS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "CRMBUILD=0"
for /f "tokens=4-6 delims=[.] " %%a in ('ver') do if "%%a"=="10" set "CRMBUILD=%%c"
if %CRMBUILD% LSS 17763 goto old
start "" "%SystemRoot%\System32\conhost.exe" --headless "%CRMPS%" -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Kira Imobiliare.ps1" -Setup
goto :eof
:old
start "" "%CRMPS%" -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0Kira Imobiliare.ps1" -Setup